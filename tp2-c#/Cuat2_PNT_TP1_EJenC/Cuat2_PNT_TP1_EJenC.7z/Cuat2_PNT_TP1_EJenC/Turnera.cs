﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Turnera
{
    private static int proximoNro = 1;
    private string idTurnera;

    public Turnera()
    {
        idTurnera = $"T{proximoNro:0000}";
    }

    public string IdTurnera
    {
        get { return idTurnera; }
    }

    public void DarTurno(int nroTurno, DateOnly fecha, TimeOnly hora, string nombreMedico, string nombrePaciente, Especialidad especialidad)
    {
        // Implementación del método DarTurno
        Console.WriteLine($"Turno {nroTurno} asignado:");
        Console.WriteLine($"ID Turnera: {idTurnera}");
        Console.WriteLine($"Fecha: {fecha}");
        Console.WriteLine($"Hora: {hora}");
        Console.WriteLine($"Médico: {nombreMedico}");
        Console.WriteLine($"Paciente: {nombrePaciente}");
        Console.WriteLine($"Especialidad: {especialidad}");
        
        proximoNro++;
    }
}
