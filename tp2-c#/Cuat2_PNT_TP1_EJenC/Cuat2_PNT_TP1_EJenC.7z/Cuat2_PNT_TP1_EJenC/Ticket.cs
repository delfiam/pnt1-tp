﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cuat2_PNT_TP1_EJenC
{
    internal class Ticket
    {
        private int nroTurno;
        private DateOnly fecha;
        private TimeOnly hora;
        private String nombreMedico;
        private String nombrePaciente;
        private Especialidad especialidad;

    public Ticket (int nroTurno, DateOnly fecha, TimeOnly hora, String nombreMedico, String nombrePaciente, Especialidad especialidad)
        {

        }
    
    }
}
