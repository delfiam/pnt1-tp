﻿public enum ObraSocial
{OSDE, PAMI, OSECAC, OSBA, MEDICUS, GALENO
}